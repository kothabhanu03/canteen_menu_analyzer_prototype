"""Bulk CSV import with row-by-row error logging."""
import csv
import os
from typing import List, Tuple
from .models import MenuItem
from .storage import clean_record, next_id
from .validation import ValidationError

REQUIRED = {"name", "category", "price"}


def import_csv(path: str, existing: List[MenuItem], log_path: str) -> Tuple[List[MenuItem], List[str]]:
    """Return (new_items, errors). Writes errors to log_path."""
    errors: List[str] = []
    added: List[MenuItem] = []
    try:
        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            headers = {h.strip().lower() for h in (reader.fieldnames or [])}
            if not REQUIRED <= headers:
                return [], [f"Header error: file must contain columns {sorted(REQUIRED)}."]
            known = {(i.name.lower(), i.category) for i in existing}
            for n, row in enumerate(reader, start=2):  # row 1 = header
                row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
                try:
                    item = clean_record(row, new_id=next_id(existing + added))
                    key = (item.name.lower(), item.category)
                    if key in known:
                        raise ValidationError("duplicate of an existing item")
                    known.add(key)
                    added.append(item)
                except (ValidationError, ValueError) as e:
                    errors.append(f"Row {n}: {e}")
    except FileNotFoundError:
        return [], [f"File not found: {path}"]
    except (UnicodeDecodeError, csv.Error) as e:
        return [], [f"Could not read file: {e}"]
    if errors:
        os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(f"Import errors for {path}\n" + "\n".join(errors) + "\n")
    return added, errors

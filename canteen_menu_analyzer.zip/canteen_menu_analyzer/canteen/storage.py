"""JSON persistence with corruption handling and atomic writes."""
import json
import os
import shutil
from typing import List, Tuple
from .models import MenuItem
from .validation import (ValidationError, validate_name, validate_category,
                         validate_price, validate_calories, validate_bool)


def clean_record(d: dict, new_id: int = None) -> MenuItem:
    """Validate a raw dict (from JSON/CSV) and return a MenuItem."""
    item_id = new_id if new_id is not None else int(d.get("id", 0))
    return MenuItem(
        id=item_id,
        name=validate_name(str(d.get("name", ""))),
        category=validate_category(str(d.get("category", ""))),
        price=validate_price(str(d.get("price", ""))),
        calories=validate_calories(str(d.get("calories", "") or "")),
        veg=validate_bool(str(d.get("veg", "yes"))),
        available=validate_bool(str(d.get("available", "yes"))),
    )


def load_items(path: str) -> Tuple[List[MenuItem], List[str]]:
    """Return (items, notices). Never raises on missing/corrupt files."""
    notices: List[str] = []
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise json.JSONDecodeError("expected a list", "", 0)
    except FileNotFoundError:
        save_items(path, [])
        return [], [f"No data file found - created a fresh one at {path}."]
    except json.JSONDecodeError:
        backup = path + ".corrupt"
        shutil.copy(path, backup)
        save_items(path, [])
        return [], [f"Data file was corrupted. Backed up to {backup}; started fresh."]
    items = []
    for i, rec in enumerate(data, 1):
        try:
            items.append(clean_record(rec))
        except (ValidationError, KeyError, TypeError, ValueError) as e:
            notices.append(f"Skipped bad stored record #{i}: {e}")
    return items, notices


def save_items(path: str, items: List[MenuItem]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump([i.to_dict() for i in items], f, indent=2)
    os.replace(tmp, path)


def next_id(items: List[MenuItem]) -> int:
    return max((i.id for i in items), default=0) + 1

"""Export summary reports: Markdown, plain-text and CSV (+ optional chart)."""
import csv
import os
from datetime import datetime
from typing import List
from .analysis import summarize
from .models import MenuItem, CURRENCY as R


def _stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def export_all(items: List[MenuItem], out_dir: str) -> List[str]:
    s = summarize(items)
    if not s["count"]:
        return []
    os.makedirs(out_dir, exist_ok=True)
    ts = _stamp()
    md = os.path.join(out_dir, f"summary_{ts}.md")
    txt = os.path.join(out_dir, f"summary_{ts}.txt")
    cs = os.path.join(out_dir, f"menu_{ts}.csv")

    lines = ["# Canteen Menu Summary", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", "",
             f"- Items: **{s['count']}** ({s['available']} available, {s['unavailable']} unavailable)",
             f"- Average price: **{R}{s['avg']:.2f}** (median {R}{s['median']:.2f})",
             f"- Cheapest: {s['cheapest'].name} ({R}{s['cheapest'].price:.2f})",
             f"- Most expensive: {s['priciest'].name} ({R}{s['priciest'].price:.2f})",
             f"- Trend: {s['trend']}", "", "| Category | Items | Avg | Min | Max |",
             "|---|---|---|---|---|"]
    for c, v in s["by_category"].items():
        lines.append(f"| {c} | {v['count']} | {v['avg']:.2f} | {v['min']:.2f} | {v['max']:.2f} |")
    if s["outliers"]:
        lines += ["", "**Price warnings:** " + ", ".join(i.name for i in s["outliers"])]
    with open(md, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    with open(txt, "w", encoding="utf-8") as f:
        f.write(f"AUDIT LOG - {datetime.now():%Y-%m-%d %H:%M:%S}\n")
        f.write(f"items={s['count']} available={s['available']} avg={s['avg']} "
                f"median={s['median']} total_value={s['total_value']}\n")
        for i in items:
            f.write(f"[{i.id:03}] {i.name:<28}{i.category:<8}{R}{i.price:>8.2f}  "
                    f"{'AVAILABLE' if i.available else 'UNAVAILABLE'}\n")

    with open(cs, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "name", "category", "price", "calories", "veg", "available"])
        for i in items:
            w.writerow([i.id, i.name, i.category, i.price, i.calories,
                        "yes" if i.veg else "no", "yes" if i.available else "no"])
    return [md, txt, cs]


def export_chart(items: List[MenuItem], out_dir: str):
    """Optional bar chart (needs matplotlib). Returns path or None."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    s = summarize(items)
    if not s["count"]:
        return None
    cats = list(s["by_category"])
    avgs = [s["by_category"][c]["avg"] for c in cats]
    plt.figure(figsize=(6, 4))
    plt.bar(cats, avgs, color="#2e7d32")
    plt.ylabel(f"Average price ({R})")
    plt.title("Average Menu Price by Category")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"chart_{_stamp()}.png")
    plt.tight_layout()
    plt.savefig(path)
    plt.close()
    return path

"""Core data structures."""
from dataclasses import dataclass, asdict

CATEGORIES = ["Main", "Side", "Drink", "Dessert", "Snack"]
CURRENCY = "Rs."


@dataclass
class MenuItem:
    id: int
    name: str
    category: str
    price: float
    calories: int = 0
    veg: bool = True
    available: bool = True

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "MenuItem":
        return cls(
            id=int(d["id"]),
            name=str(d["name"]),
            category=str(d["category"]),
            price=float(d["price"]),
            calories=int(d.get("calories", 0)),
            veg=bool(d.get("veg", True)),
            available=bool(d.get("available", True)),
        )

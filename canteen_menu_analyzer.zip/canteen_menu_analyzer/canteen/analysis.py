"""Core business logic: summaries, search and affordable meal combinations."""
import itertools
import statistics
from typing import Dict, List, Optional
from .models import MenuItem, CATEGORIES

DEFAULT_COMBO = ("Main", "Side", "Drink")


def search(items: List[MenuItem], keyword: str = "", category: str = "",
           max_price: Optional[float] = None, veg_only: bool = False) -> List[MenuItem]:
    kw = keyword.strip().lower()
    out = []
    for i in items:
        if kw and kw not in i.name.lower() and kw not in i.category.lower():
            continue
        if category and i.category != category:
            continue
        if max_price is not None and i.price > max_price:
            continue
        if veg_only and not i.veg:
            continue
        out.append(i)
    return out


def find_outliers(items: List[MenuItem]) -> List[MenuItem]:
    """Items priced > 2 standard deviations above their category mean."""
    flagged = []
    for cat in CATEGORIES:
        group = [i for i in items if i.category == cat]
        if len(group) < 4:
            continue
        prices = [i.price for i in group]
        mean, sd = statistics.mean(prices), statistics.pstdev(prices)
        if sd == 0:
            continue
        flagged += [i for i in group if i.price > mean + 2 * sd]
    return flagged


def summarize(items: List[MenuItem]) -> Dict:
    if not items:
        return {"count": 0}
    prices = [i.price for i in items]
    by_cat = {}
    for cat in CATEGORIES:
        p = [i.price for i in items if i.category == cat]
        if p:
            by_cat[cat] = {"count": len(p), "avg": round(statistics.mean(p), 2),
                           "min": min(p), "max": max(p)}
    cheapest = min(items, key=lambda i: i.price)
    priciest = max(items, key=lambda i: i.price)
    avg_cat = max(by_cat, key=lambda c: by_cat[c]["avg"])
    return {
        "count": len(items),
        "available": sum(i.available for i in items),
        "unavailable": sum(not i.available for i in items),
        "veg": sum(i.veg for i in items),
        "total_value": round(sum(prices), 2),
        "avg": round(statistics.mean(prices), 2),
        "median": round(statistics.median(prices), 2),
        "cheapest": cheapest, "priciest": priciest,
        "by_category": by_cat,
        "trend": f"{avg_cat} is the highest-priced category on average "
                 f"(Rs.{by_cat[avg_cat]['avg']:.2f}).",
        "outliers": find_outliers(items),
        "missing_calories": [i for i in items if i.calories == 0],
    }


def affordable_combos(items: List[MenuItem], budget: float,
                      categories=DEFAULT_COMBO, veg_only: bool = False,
                      sort: str = "cheapest", limit: int = 10) -> List[Dict]:
    """One item from each category in `categories`, total <= budget.
    sort: 'cheapest' (lowest total first) or 'budget' (uses the budget best)."""
    pools = []
    for cat in categories:
        pool = [i for i in items if i.category == cat and i.available
                and (i.veg or not veg_only)]
        if not pool:
            return []
        pools.append(pool)
    combos = []
    for combo in itertools.product(*pools):
        total = round(sum(i.price for i in combo), 2)
        if total <= budget:
            combos.append({"items": list(combo), "total": total,
                           "calories": sum(i.calories for i in combo),
                           "left": round(budget - total, 2)})
    combos.sort(key=lambda c: c["total"], reverse=(sort == "budget"))
    return combos[:limit] if limit else combos

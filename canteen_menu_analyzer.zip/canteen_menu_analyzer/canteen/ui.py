"""Interactive terminal interface (menu-driven)."""
import os
from . import analysis, export, importer, storage
from .models import CATEGORIES, CURRENCY as R, MenuItem
from .validation import (ValidationError, validate_name, validate_category, validate_price,
                         validate_calories, validate_bool, validate_budget)

GREEN, YELLOW, RED, CYAN, BOLD, END = "\033[92m", "\033[93m", "\033[91m", "\033[96m", "\033[1m", "\033[0m"
PAGE = 15

BANNER = f"""{GREEN}{BOLD}
  ==========================================
     CANTEEN MENU ANALYZER   |  GreenFuture
     Summarize prices. Find affordable meals.
  =========================================={END}"""

MENU = """
  1) View menu            6) Executive summary
  2) Add item             7) Affordable meal combos
  3) Search / filter      8) Import CSV
  4) Update item          9) Export reports
  5) Delete item         10) Price chart
  0) Exit
"""


def ask(prompt, validator, default=None):
    """Loop until the validator accepts the input."""
    while True:
        shown = f"{prompt} [{default}]: " if default is not None else f"{prompt}: "
        raw = input(shown).strip()
        if raw == "" and default is not None:
            raw = str(default)
        try:
            return validator(raw)
        except ValidationError as e:
            print(f"{RED}  x {e}{END}")


def info(msg): print(f"{CYAN}{msg}{END}")
def ok(msg): print(f"{GREEN}  v {msg}{END}")
def warn(msg): print(f"{YELLOW}  ! {msg}{END}")


def table(items, paginate=True):
    if not items:
        print("  (no items)")
        return
    head = f"{'ID':>3} | {'Name':<28} | {'Category':<8} | {'Price':>9} | {'Cal':>4} | Veg | Avail"
    print(BOLD + head + END + "\n" + "-" * len(head))
    for n, i in enumerate(items, 1):
        print(f"{i.id:>3} | {i.name:<28} | {i.category:<8} | {R}{i.price:>6.2f} | "
              f"{i.calories:>4} | {'Y' if i.veg else 'N':^3} | {'Yes' if i.available else 'NO'}")
        if paginate and n % PAGE == 0 and n < len(items):
            if input(f"  -- {n}/{len(items)} shown, Enter for more, q to stop: ").strip().lower() == "q":
                break
    print(f"  {len(items)} item(s)")


def find_item(items, raw):
    try:
        return next(i for i in items if i.id == int(raw))
    except (ValueError, StopIteration):
        return None


class App:
    def __init__(self, data_dir):
        self.data_file = os.path.join(data_dir, "menu.json")
        self.export_dir = os.path.join(os.path.dirname(data_dir.rstrip("/\\")) or ".", "exports")
        self.items, notices = storage.load_items(self.data_file)
        for n in notices:
            warn(n)

    def save(self):
        storage.save_items(self.data_file, self.items)

    # -- actions ---------------------------------------------------------
    def add(self):
        info("Add a new menu item")
        name = ask("  Name", validate_name)
        cat = ask(f"  Category ({'/'.join(CATEGORIES)})", validate_category)
        price = ask("  Price", validate_price)
        cal = ask("  Calories (blank = unknown)", validate_calories, default="")
        veg = ask("  Vegetarian? (y/n)", validate_bool, default="y")
        if any(i.name.lower() == name.lower() and i.category == cat for i in self.items):
            return warn("That item already exists in this category.")
        self.items.append(MenuItem(storage.next_id(self.items), name, cat, price, cal, veg, True))
        self.save()
        ok(f"Added '{name}' at {R}{price:.2f}.")

    def search(self):
        kw = input("  Keyword (blank = any): ").strip()
        cat = input(f"  Category ({'/'.join(CATEGORIES)}, blank = any): ").strip()
        try:
            cat = validate_category(cat) if cat else ""
        except ValidationError as e:
            return warn(str(e))
        mp = input("  Max price (blank = any): ").strip()
        try:
            mp = validate_price(mp) if mp else None
        except ValidationError as e:
            return warn(str(e))
        veg = input("  Veg only? (y/n, blank = n): ").strip().lower() in ("y", "yes")
        table(analysis.search(self.items, kw, cat, mp, veg))

    def update(self):
        item = find_item(self.items, input("  Item ID to update: "))
        if not item:
            return warn("No item with that ID.")
        print(f"  Editing: {item.name} ({R}{item.price:.2f})  - press Enter to keep a value")
        item.price = ask("  New price", validate_price, default=item.price)
        item.available = ask("  Available? (y/n)", validate_bool, default="y" if item.available else "n")
        self.save()
        ok("Item updated.")

    def delete(self):
        item = find_item(self.items, input("  Item ID to delete: "))
        if not item:
            return warn("No item with that ID.")
        if ask(f"  Delete '{item.name}'? (y/n)", validate_bool, default="n"):
            self.items.remove(item)
            self.save()
            ok("Deleted.")

    def summary(self):
        s = analysis.summarize(self.items)
        if not s["count"]:
            return warn("Menu is empty.")
        info("EXECUTIVE SUMMARY")
        print(f"  Items: {s['count']}  (available {s['available']}, unavailable {s['unavailable']}, veg {s['veg']})")
        print(f"  Average price: {R}{s['avg']:.2f}   Median: {R}{s['median']:.2f}   Total menu value: {R}{s['total_value']:.2f}")
        print(f"  Cheapest : {s['cheapest'].name} ({R}{s['cheapest'].price:.2f})")
        print(f"  Priciest : {s['priciest'].name} ({R}{s['priciest'].price:.2f})")
        print(f"\n  {'Category':<9}{'Items':>6}{'Avg':>9}{'Min':>9}{'Max':>9}")
        for c, v in s["by_category"].items():
            print(f"  {c:<9}{v['count']:>6}{v['avg']:>9.2f}{v['min']:>9.2f}{v['max']:>9.2f}")
        print(f"\n  Trend: {s['trend']}")
        for i in s["outliers"]:
            warn(f"Price anomaly: {i.name} ({R}{i.price:.2f}) is far above other {i.category} items.")
        if s["unavailable"]:
            warn(f"{s['unavailable']} item(s) currently unavailable.")
        if s["missing_calories"]:
            warn(f"{len(s['missing_calories'])} item(s) have no calorie data.")

    def combos(self):
        budget = ask("  Your budget", validate_budget)
        veg = ask("  Vegetarian only? (y/n)", validate_bool, default="n")
        mode = input("  Sort: 1 = cheapest first, 2 = best use of budget [1]: ").strip()
        res = analysis.affordable_combos(self.items, budget, veg_only=veg,
                                         sort="budget" if mode == "2" else "cheapest")
        if not res:
            return warn(f"No Main + Side + Drink combo fits within {R}{budget:.2f}.")
        info(f"Top meal combos (Main + Side + Drink) within {R}{budget:.2f}")
        for n, c in enumerate(res, 1):
            names = " + ".join(i.name for i in c["items"])
            print(f"  {n:>2}. {names}\n      total {R}{c['total']:.2f} | left {R}{c['left']:.2f} | {c['calories']} kcal")
        if sum(1 for _ in analysis.affordable_combos(self.items, budget, limit=0)) > len(res):
            print("  (showing first 10)")

    def import_csv(self):
        path = input("  CSV file path: ").strip().strip('"')
        log = os.path.join(self.export_dir, "import_errors.log")
        added, errors = importer.import_csv(path, self.items, log)
        self.items.extend(added)
        if added:
            self.save()
        ok(f"Imported {len(added)} row(s).")
        if errors:
            warn(f"{len(errors)} problem(s); details in {log}")
            for e in errors[:5]:
                print(f"    {e}")
            if len(errors) > 5:
                print(f"    ... and {len(errors) - 5} more")

    def export(self):
        paths = export.export_all(self.items, self.export_dir)
        if not paths:
            return warn("Nothing to export.")
        for p in paths:
            ok(f"Wrote {p}")

    def chart(self):
        path = export.export_chart(self.items, self.export_dir)
        if path:
            ok(f"Chart saved: {path}")
        else:
            warn("Chart needs matplotlib (pip install matplotlib) and a non-empty menu.")

    # -- main loop -------------------------------------------------------
    def run(self):
        print(BANNER)
        actions = {"1": lambda: table(self.items), "2": self.add, "3": self.search,
                   "4": self.update, "5": self.delete, "6": self.summary,
                   "7": self.combos, "8": self.import_csv, "9": self.export, "10": self.chart}
        while True:
            print(MENU)
            choice = input("Choose an option: ").strip()
            if choice == "0":
                print("Goodbye!")
                return
            action = actions.get(choice)
            if action is None:
                warn("Please enter a number from the menu.")
                continue
            try:
                action()
            except (KeyboardInterrupt, EOFError):
                print("\n  (cancelled)")

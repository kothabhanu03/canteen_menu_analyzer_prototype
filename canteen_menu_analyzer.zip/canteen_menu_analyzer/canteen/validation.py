"""Defensive input validation. Every validator takes a string and returns a clean
value, or raises ValidationError with a friendly message."""
import math
import re
from .models import CATEGORIES

MIN_PRICE, MAX_PRICE = 1.0, 1000.0
MAX_CALORIES = 3000


class ValidationError(ValueError):
    pass


def validate_name(raw: str) -> str:
    name = re.sub(r"\s+", " ", (raw or "").strip())
    if not name:
        raise ValidationError("Name cannot be blank.")
    if len(name) > 40:
        raise ValidationError("Name must be 40 characters or fewer.")
    if not re.fullmatch(r"[A-Za-z0-9 '&().,/-]+", name):
        raise ValidationError("Name has unsupported characters.")
    return name.title() if name.islower() else name


def validate_category(raw: str) -> str:
    key = (raw or "").strip().lower()
    for c in CATEGORIES:
        if c.lower() == key:
            return c
    raise ValidationError(f"Category must be one of: {', '.join(CATEGORIES)}.")


def validate_price(raw: str) -> float:
    text = re.sub(r"(?i)rs\.?|₹|,|\s", "", str(raw))
    if not text:
        raise ValidationError("Price cannot be blank.")
    try:
        value = float(text)
    except ValueError:
        raise ValidationError(f"'{raw}' is not a number.") from None
    if math.isnan(value) or math.isinf(value):
        raise ValidationError("Price must be a finite number.")
    if not MIN_PRICE <= value <= MAX_PRICE:
        raise ValidationError(f"Price must be between {MIN_PRICE:g} and {MAX_PRICE:g}.")
    return round(value, 2)


def validate_calories(raw: str) -> int:
    text = str(raw).strip()
    if text == "":
        return 0
    try:
        value = int(float(text))
    except ValueError:
        raise ValidationError(f"'{raw}' is not a valid calorie count.") from None
    if not 0 <= value <= MAX_CALORIES:
        raise ValidationError(f"Calories must be between 0 and {MAX_CALORIES}.")
    return value


def validate_bool(raw: str) -> bool:
    key = str(raw).strip().lower()
    if key in {"y", "yes", "true", "1", "t"}:
        return True
    if key in {"n", "no", "false", "0", "f"}:
        return False
    raise ValidationError("Please answer y or n.")


def validate_budget(raw: str) -> float:
    try:
        return validate_price(raw)
    except ValidationError as e:
        raise ValidationError(str(e).replace("Price", "Budget")) from None

"""Canteen Menu Analyzer - summarize menu prices and find affordable meal combos."""
__version__ = "1.0.0"

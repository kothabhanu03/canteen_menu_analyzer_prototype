import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from canteen import analysis, storage, importer
from canteen.validation import *


class TestValidation(unittest.TestCase):
    def test_price(self):
        self.assertEqual(validate_price("45.678"), 45.68)
        self.assertEqual(validate_price("₹50"), 50.0)
        for bad in ["", "abc", "0", "-5", "1001", "nan", "inf"]:
            with self.assertRaises(ValidationError):
                validate_price(bad)

    def test_category_name(self):
        self.assertEqual(validate_category("drink"), "Drink")
        with self.assertRaises(ValidationError):
            validate_category("soup")
        with self.assertRaises(ValidationError):
            validate_name("   ")
        with self.assertRaises(ValidationError):
            validate_name("x" * 41)

    def test_bool_calories(self):
        self.assertTrue(validate_bool("Y")); self.assertFalse(validate_bool("no"))
        with self.assertRaises(ValidationError):
            validate_bool("maybe")
        self.assertEqual(validate_calories(""), 0)
        with self.assertRaises(ValidationError):
            validate_calories("5000")


class TestLogic(unittest.TestCase):
    def setUp(self):
        d = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "menu.json")
        self.items, _ = storage.load_items(d)

    def test_sample_loads(self):
        self.assertGreaterEqual(len(self.items), 30)

    def test_combos_within_budget(self):
        res = analysis.affordable_combos(self.items, 60, limit=0)
        self.assertTrue(res)
        self.assertTrue(all(c["total"] <= 60 for c in res))
        self.assertEqual(res, sorted(res, key=lambda c: c["total"]))
        self.assertEqual(analysis.affordable_combos(self.items, 5), [])

    def test_summary_and_outlier(self):
        s = analysis.summarize(self.items)
        self.assertEqual(s["count"], len(self.items))
        self.assertIn("Family Thali Platter", [i.name for i in s["outliers"]])

    def test_search(self):
        self.assertTrue(all(i.price <= 20 for i in analysis.search(self.items, max_price=20)))
        self.assertTrue(all(i.veg for i in analysis.search(self.items, veg_only=True)))


class TestPersistence(unittest.TestCase):
    def test_missing_and_corrupt(self):
        with tempfile.TemporaryDirectory() as t:
            p = os.path.join(t, "menu.json")
            items, notes = storage.load_items(p)
            self.assertEqual(items, []); self.assertTrue(notes)
            with open(p, "w") as f:
                f.write("{not json")
            items, notes = storage.load_items(p)
            self.assertEqual(items, []); self.assertTrue(os.path.exists(p + ".corrupt"))

    def test_import_errors(self):
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        with tempfile.TemporaryDirectory() as t:
            added, errs = importer.import_csv(os.path.join(base, "data", "sample_bad_import.csv"),
                                              [], os.path.join(t, "err.log"))
            self.assertEqual(len(added), 4)
            self.assertEqual(len(errs), 7)
            self.assertTrue(os.path.exists(os.path.join(t, "err.log")))


if __name__ == "__main__":
    unittest.main()

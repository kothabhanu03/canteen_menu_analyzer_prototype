"""Canteen Menu Analyzer - entry point.  Run:  python main.py"""
import os
import sys
from canteen.ui import App


def main():
    base = os.path.dirname(os.path.abspath(__file__))
    try:
        App(os.path.join(base, "data")).run()
    except (KeyboardInterrupt, EOFError):
        print("\nGoodbye!")
        sys.exit(0)


if __name__ == "__main__":
    main()

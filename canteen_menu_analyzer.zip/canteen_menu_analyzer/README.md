# Canteen Menu Analyzer

GreenFuture Hack - Project #63 (Food & Agriculture). A beginner-friendly, menu-driven Python app that
summarizes canteen menu prices and finds affordable meal combinations.

## Run
```
python main.py            # Python 3.10+, standard library only
python -m unittest discover -s tests    # run the tests
pip install matplotlib    # optional, only for the price chart (menu option 10)
```

## Features
| Requirement | Where |
|---|---|
| Interactive terminal menu (ANSI colours, pagination) | `canteen/ui.py` |
| Defensive input validation (type, range, blank, NaN, categories) | `canteen/validation.py` |
| Business logic: summaries, outliers, affordable Main+Side+Drink combos | `canteen/analysis.py` |
| JSON persistence, atomic saves, corrupt/missing file recovery | `canteen/storage.py` |
| Search by keyword / category / max price / veg-only | menu option 3 |
| Executive summary (totals, averages, trend, warnings) | menu option 6 |
| Export Markdown, plain-text audit log, CSV | `canteen/export.py`, option 9 |
| Threshold warnings (price anomalies, unavailable items, missing calories) | option 6 |
| Bulk CSV import with row-by-row error log | `canteen/importer.py`, option 8 |
| Price chart (optional) | option 10 |

## Demo script (5 minutes)
1. `python main.py` - show the banner and menu.
2. Option 2: enter category `soup`, price `abc`, then `-5` - watch validation reject each; then enter valid values.
3. Option 6: summary table + anomaly warning (Family Thali Platter).
4. Option 7: budget `60` for combos; try `3` to show the "no combo fits" message.
5. Option 8: import `data/sample_bad_import.csv` - 3 rows added, errors logged to `exports/import_errors.log`.
6. Exit (0), relaunch, option 1 - data persisted. Option 9/10 - exported report and chart.

## Data
- `data/menu.json` - live data store (40 seeded items, incl. boundary values such as Rs.1 pickle and an Rs.480 outlier)
- `data/sample_menu.csv` - same dataset as CSV
- `data/sample_bad_import.csv` - messy rows to demo validation and error logging

To reset, delete `data/menu.json`; the app recreates an empty one (re-import `sample_menu.csv`).
